OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Хавтасны нэр",
    "Groups" : "бүлэгүүд",
    "Quota" : " хувь хэмжээ",
    "Create" : "Үүсгэх",
    "Delete" : "Устгах",
    "Share" : "Түгээх"
},
"nplurals=2; plural=(n != 1);");
