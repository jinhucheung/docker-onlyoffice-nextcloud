OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Nom del dorsièr",
    "Groups" : "Gropes",
    "Read" : "Legit",
    "Create" : "Crear",
    "Delete" : "Suprimir",
    "Share" : "Partejar"
},
"nplurals=2; plural=(n > 1);");
