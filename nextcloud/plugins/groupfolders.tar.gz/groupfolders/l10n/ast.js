OC.L10N.register(
    "groupfolders",
    {
    "Delete \"{folderName}\"?" : "¿Desaniciar «{folderName}»?",
    "Folder name" : "Nome de carpeta",
    "Groups" : "Grupos",
    "Quota" : "Cuota",
    "Group folders" : "Carpetes de grupos",
    "Read" : "Lleer",
    "Create" : "Crear",
    "Delete" : "Desaniciar",
    "Share" : "Share",
    "You" : "Tu"
},
"nplurals=2; plural=(n != 1);");
