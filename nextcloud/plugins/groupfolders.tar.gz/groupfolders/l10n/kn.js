OC.L10N.register(
    "groupfolders",
    {
    "Groups" : "﻿ಗುಂಪುಗಳು",
    "Quota" : "ಪಾಲು",
    "Create" : "ಸೃಷ್ಟಿಸಿ",
    "Delete" : "﻿ಅಳಿಸಿ",
    "Share" : "﻿ಹಂಚಿಕೊಳ್ಳಿ"
},
"nplurals=2; plural=(n > 1);");
