OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Denumire director",
    "Groups" : "Grupuri",
    "Quota" : "Procent",
    "Deny" : "Refuzați",
    "Allow" : "Permiteți",
    "Read" : "Citeşte",
    "Create" : "Creează",
    "Delete" : "Șterge",
    "Share" : "Partajează"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
