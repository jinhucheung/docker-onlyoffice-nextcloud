OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Tên thư mục",
    "Groups" : "Nhóm",
    "Quota" : "Hạn ngạch",
    "Deny" : "Từ chối",
    "Allow" : "Cho phép",
    "Read" : "Đọc",
    "Create" : "Tạo mới",
    "Delete" : "Xóa",
    "Share" : "Chia sẻ",
    "You" : "Bạn"
},
"nplurals=1; plural=0;");
