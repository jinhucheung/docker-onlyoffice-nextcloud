OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "ชื่อโฟลเดอร์",
    "Groups" : "กลุ่ม",
    "Quota" : "โควต้า",
    "Read" : "อ่าน",
    "Create" : "สร้าง",
    "Delete" : "ลบ",
    "Share" : "แชร์"
},
"nplurals=1; plural=0;");
