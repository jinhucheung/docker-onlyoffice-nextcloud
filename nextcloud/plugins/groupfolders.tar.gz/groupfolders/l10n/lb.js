OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Dossiers Numm:",
    "Groups" : "Gruppen",
    "Quota" : "Quota",
    "Create" : "Erstellen",
    "Delete" : "Läschen",
    "Share" : "Deelen"
},
"nplurals=2; plural=(n != 1);");
