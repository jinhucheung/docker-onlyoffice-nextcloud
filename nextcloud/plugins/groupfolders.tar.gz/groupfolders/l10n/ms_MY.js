OC.L10N.register(
    "groupfolders",
    {
    "Groups" : "Kumpulan",
    "Quota" : "Kuota",
    "Create" : "Buat",
    "Delete" : "Padam",
    "Share" : "Kongsi"
},
"nplurals=1; plural=0;");
