OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Nomine de dossier",
    "Groups" : "Gruppos",
    "Quota" : "Quota",
    "Create" : "Crear",
    "Delete" : "Deler",
    "Share" : "Compartir",
    "You" : "Tu"
},
"nplurals=2; plural=(n != 1);");
