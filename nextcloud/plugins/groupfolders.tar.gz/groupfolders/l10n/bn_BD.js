OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "ফোলডারের নাম",
    "Groups" : "গোষ্ঠীসমূহ",
    "Quota" : "কোটা",
    "Read" : "পড়",
    "Create" : "তৈরী কর",
    "Delete" : "মুছে",
    "Share" : "ভাগাভাগি কর"
},
"nplurals=2; plural=(n != 1);");
