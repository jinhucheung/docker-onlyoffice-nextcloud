OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Papka nomi",
    "Groups" : "Guruhlar",
    "Group folders" : "Guruh papkalari",
    "Delete" : "O'chir"
},
"nplurals=1; plural=0;");
