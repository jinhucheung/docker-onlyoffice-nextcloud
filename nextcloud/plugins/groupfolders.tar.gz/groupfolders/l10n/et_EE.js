OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Kausta nimi",
    "Groups" : "Grupid",
    "Quota" : "Kvoot",
    "Group folders" : "Grupikaustad",
    "Read" : "Lugemine",
    "Create" : "Loo",
    "Delete" : "Kustuta",
    "Share" : "Jaga"
},
"nplurals=2; plural=(n != 1);");
