OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "資料夾名稱",
    "Groups" : "群組",
    "Create" : "新增",
    "Delete" : "刪除",
    "Share" : "分享"
},
"nplurals=1; plural=0;");
