OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Qovluq adı",
    "Groups" : "Qruplar",
    "Quota" : "Norma",
    "Read" : "Oxu",
    "Create" : "Yarat",
    "Delete" : "Sil",
    "Share" : "Paylaş"
},
"nplurals=2; plural=(n != 1);");
