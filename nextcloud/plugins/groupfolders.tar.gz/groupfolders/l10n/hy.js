OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Պանակի անուն",
    "Groups" : "Խմբեր",
    "Create" : "Ստեղծել",
    "Delete" : "հեռացնել",
    "Share" : "Կիսվել"
},
"nplurals=2; plural=(n != 1);");
