OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Nombre de la carpeta",
    "Groups" : "Grupos",
    "Quota" : "Cuota",
    "Group folders" : "Carpetas de grupo",
    "Read" : "Leer",
    "Write" : "Escribir",
    "Create" : "Crear",
    "Delete" : "Borrar",
    "Share" : "Compartir",
    "You" : "Tú"
},
"nplurals=2; plural=(n != 1);");
