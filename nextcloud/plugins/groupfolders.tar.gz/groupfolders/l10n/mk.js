OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Име на папка",
    "Groups" : "Групи",
    "Quota" : "Квота",
    "Group folders" : "Групни папки",
    "Deny" : "Забрани",
    "Allow" : "Дозволи",
    "Read" : "Читај",
    "Create" : "Креирај",
    "Delete" : "Избриши",
    "Share" : "Сподели",
    "You" : "Ти"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
