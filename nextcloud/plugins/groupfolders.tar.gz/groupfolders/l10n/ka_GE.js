OC.L10N.register(
    "groupfolders",
    {
    "Are you sure you want to delete \"{folderName}\" and all files inside? This operation can not be undone" : "დარწმუნებული ხართ, რომ გსურთ გააუქმოთ \"{folderName}\" და ყველა ფაილი მასში? ეს ოპერაცია ვერ იქნება უკუქცეული",
    "Delete \"{folderName}\"?" : "გავაუქმოთ \"{folderName}\"?",
    "Folder name" : "დირექტორიის სახელი",
    "Groups" : "ჯგუფები",
    "Quota" : "ქვოტა",
    "Group folders" : "ჯგუფური დირექტორიები",
    "Read" : "წაკითხვა",
    "Write" : "ჩაწერა",
    "Create" : "შექმნა",
    "Delete" : "წაშლა",
    "Share" : "გაზიარება",
    "You" : "თქვენ"
},
"nplurals=2; plural=(n!=1);");
