OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "ෆොල්ඩරයේ නම",
    "Groups" : "කණ්ඩායම්",
    "Quota" : "සලාකය",
    "Group folders" : "කණ්ඩායම් ගොනු",
    "Create" : "තනන්න",
    "Delete" : "ඉවත් කරන්න",
    "Share" : "බෙදා හදා ගන්න"
},
"nplurals=2; plural=(n != 1);");
