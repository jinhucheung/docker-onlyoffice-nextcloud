OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Nama Folder",
    "Groups" : "Grup",
    "Quota" : "Kuota",
    "Deny" : "Tolak",
    "Allow" : "Izinkan",
    "Read" : "Baca",
    "Create" : "Buat",
    "Delete" : "Hapus",
    "Share" : "Bagikan"
},
"nplurals=1; plural=0;");
