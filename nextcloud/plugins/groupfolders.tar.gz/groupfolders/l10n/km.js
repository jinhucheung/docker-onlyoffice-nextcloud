OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "ឈ្មោះ​ថត",
    "Groups" : "ក្រុ",
    "Create" : "បង្កើត",
    "Delete" : "លុប",
    "Share" : "ចែក​រំលែក"
},
"nplurals=1; plural=0;");
