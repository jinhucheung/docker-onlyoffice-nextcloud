OC.L10N.register(
    "groupfolders",
    {
    "Are you sure you want to delete \"{folderName}\" and all files inside? This operation can not be undone" : "شبش",
    "Groups" : "ګروپونه",
    "Delete" : "ړنګول",
    "Share" : "شریکول"
},
"nplurals=2; plural=(n != 1);");
