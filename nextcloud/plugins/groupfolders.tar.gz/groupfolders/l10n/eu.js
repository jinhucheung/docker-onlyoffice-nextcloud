OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Karpetaren izena",
    "Groups" : "Taldeak",
    "Quota" : "Kuota",
    "Group folders" : "Talde karpetak",
    "Denied" : "Ukatuta",
    "Denied (Inherited permission)" : "Ukatua (Heredatutako baimena)",
    "Deny" : "Ukatu",
    "Allow" : "Baimendu",
    "Read" : "Irakurri",
    "Write" : "Idatzi",
    "Create" : "Sortu",
    "Delete" : "Ezabatu",
    "Share" : "Partekatu",
    "You" : "Zu "
},
"nplurals=2; plural=(n != 1);");
