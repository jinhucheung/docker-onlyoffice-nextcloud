OC.L10N.register(
    "groupfolders",
    {
    "Groups" : "Bólkar",
    "Delete" : "Strika"
},
"nplurals=2; plural=(n != 1);");
