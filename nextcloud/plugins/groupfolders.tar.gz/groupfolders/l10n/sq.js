OC.L10N.register(
    "groupfolders",
    {
    "Delete \"{folderName}\"?" : "Fshini \"{folderName}\"?",
    "Folder name" : "Emri i dosjes",
    "Groups" : "Grupet",
    "Quota" : "Kuotë",
    "Group folders" : "Dosjet e grupit",
    "Deny" : "Refuzo",
    "Allow" : "Lejo",
    "Read" : "Lexoni",
    "Write" : "Shkruaj",
    "Create" : "Krijo",
    "Delete" : "Delete",
    "Share" : "Shpërndaje",
    "You" : "Ju"
},
"nplurals=2; plural=(n != 1);");
