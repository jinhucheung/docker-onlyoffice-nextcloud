OC.L10N.register(
    "groupfolders",
    {
    "Delete" : "حذف کریں",
    "Share" : "تقسیم"
},
"nplurals=2; plural=(n != 1);");
