OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Nombre de la carpeta",
    "Groups" : "Grupos",
    "Quota" : "Cuota",
    "Group folders" : "Carpetas de grupo",
    "Deny" : "Rechazar",
    "Allow" : "Permitir",
    "Read" : "Leer",
    "Write" : "Escribir",
    "Create" : "Crear",
    "Delete" : "Eliminar",
    "Share" : "Compartir",
    "You" : "Usted"
},
"nplurals=2; plural=(n != 1);");
