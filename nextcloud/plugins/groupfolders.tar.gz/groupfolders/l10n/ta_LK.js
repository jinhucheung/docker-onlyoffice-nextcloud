OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "கோப்புறை பெயர்",
    "Groups" : "குழுக்கள்",
    "Quota" : "பங்கு",
    "Create" : "உருவாக்குக",
    "Delete" : "நீக்குக",
    "Share" : "பகிர்வு"
},
"nplurals=2; plural=(n != 1);");
