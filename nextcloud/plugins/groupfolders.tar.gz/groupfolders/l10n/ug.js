OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "قىسقۇچ ئاتى",
    "Groups" : "گۇرۇپپا",
    "Create" : "قۇر",
    "Delete" : "ئۆچۈر",
    "Share" : "ھەمبەھىر"
},
"nplurals=1; plural=0;");
