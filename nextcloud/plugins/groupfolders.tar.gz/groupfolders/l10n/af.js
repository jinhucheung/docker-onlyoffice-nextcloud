OC.L10N.register(
    "groupfolders",
    {
    "Folder name" : "Vouernaam",
    "Groups" : "Groepe",
    "Quota" : "Kwota",
    "Group folders" : "Groepvouers",
    "Create" : "Skep",
    "Delete" : "Skrap",
    "Share" : "Deel"
},
"nplurals=2; plural=(n != 1);");
