<?php script($_['appId'], ['../build/settings']); ?>
<?php style($_['appId'], ['../build/settings']); ?>
<div id="searchresults" style="display: none"></div>
<div id="groupfolders-wrapper">
	<h2>Group folders</h2>
	<div id="groupfolders-root"/>
</div>
